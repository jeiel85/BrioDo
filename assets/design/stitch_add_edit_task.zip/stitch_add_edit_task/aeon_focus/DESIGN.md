# Design System Documentation: The Productivity Director’s Guide

This document defines the visual and structural language for a high-end, productivity-focused interface. We are moving beyond the "utility-first" look of standard task managers toward an editorial, intentional experience that rewards focus and celebrates achievement.

## 1. Creative North Star: "The Mindful Curator"
The goal is not just to list tasks, but to provide a sanctuary for work. We achieve this through **The Mindful Curator** aesthetic—a blend of soft minimalism and high-end editorial layouts. 

To break the "template" look:
- **Intentional Asymmetry:** Avoid perfectly centered grids. Use off-balance header alignments to lead the eye.
- **Layered Transitions:** UI elements shouldn't just "appear"; they should emerge through subtle tonal shifts and depth.
- **Negative Space as Content:** Treat `spacing-16` and `spacing-24` not as empty gaps, but as essential "breathing room" that separates high-priority focus areas.

---

## 2. Color & Tonal Architecture
Our palette uses sophisticated, cool-toned neutrals and vibrant productivity accents. We move beyond flat design by utilizing Material Design tokens to create a "physical" sense of layering.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders for sectioning or containment. 
Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` (#f4f3fa) task list sitting on a `surface` (#faf8fe) background provides all the separation a user needs without the visual "noise" of a line.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked sheets. Use these tiers to define importance:
- **Base Layer:** `surface` (#faf8fe)
- **Secondary Content Areas:** `surface-container-low` (#f4f3fa)
- **Primary Interaction Cards:** `surface-container-lowest` (#ffffff)
- **Floating Overlays:** `surface-container-high` (#e8e7f1)

### The "Glass & Gradient" Signature
For main Action Buttons or Hero headers, use a subtle linear gradient from `primary` (#0053dc) to `primary-container` (#3e76fe) at a 135-degree angle. This adds "soul" and a premium feel that flat hex codes cannot replicate.

---

## 3. Typography: The Editorial Voice
We use a dual-typeface system to balance professional authority with modern approachability.

*   **Display & Headlines (Manrope):** High-end, geometric, and authoritative. Use `display-lg` for daily overviews and `headline-md` for category headers.
*   **Body & Labels (Inter):** Highly legible and neutral. Inter handles the "work" of the app—task names, descriptions, and metadata.

**Hierarchy Tip:** Use `on-surface-variant` (#5d5f68) for secondary metadata like "Created 2 hours ago" to ensure the primary task title in `on-surface` (#30323b) commands immediate attention.

---

## 4. Elevation & Depth
In this system, depth is achieved through **Tonal Layering** and **Ambient Light**, never heavy shadows.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift.
*   **Ambient Shadows:** For floating elements (Modals, Popovers), use an extra-diffused shadow: `box-shadow: 0 12px 32px rgba(48, 50, 59, 0.06);`. The shadow color is a 6% opacity tint of `on-surface`, mimicking natural light.
*   **Ghost Border Fallback:** If a border is required for accessibility, use `outline-variant` (#b0b1bc) at **15% opacity**.
*   **Glassmorphism:** For top navigation bars or floating action buttons, use `surface` at 80% opacity with a `backdrop-blur: 12px`. This integrates the UI rather than sectioning it off.

---

## 5. Components & Primitive Styling

### Buttons (The "Soft-Touch" Interaction)
- **Primary:** Gradient (`primary` to `primary-container`), `rounded-md` (0.75rem). Text: `on-primary-fixed`.
- **Secondary:** `secondary-container` (#85f8c4) background with `on-secondary-container` (#005e40) text. This provides a "Success/Friendly" vibe for completion actions.
- **Tertiary:** No background. Use `primary` text. Use `spacing-3` for horizontal padding.

### Tasks & Cards
- **The Rule:** Forbid divider lines between tasks. Use `spacing-2` of vertical white space and a hover state of `surface-container-high` to define rows.
- **Corner Radius:** All cards must use `rounded-lg` (1rem). Small tags/chips use `rounded-full`.

### Productivity Inputs
- **Input Fields:** Use `surface-container-low` with a `rounded-md` corner. On focus, shift background to `surface-container-lowest` and add a 1px "Ghost Border" of `primary` at 40% opacity.
- **Checkboxes:** When checked, transition from `outline` to `secondary` (#006d4b). The "Success" green should feel like a reward.

### Specialized Component: The Focus "Orb"
Create a floating progress indicator using `tertiary-container` (#8342f4) with a heavy blur. This serves as a "visual anchor" for the user’s current most important task.

---

## 6. Do’s and Don’ts

### Do
- **Do** use `spacing-10` to `spacing-16` for major section margins to create an "Editorial" feel.
- **Do** use `secondary` greens for "Complete" states to reinforce a positive productivity loop.
- **Do** use `tertiary` (#742fe5) sparingly for "High Priority" or "Deep Work" modes.

### Don’t
- **Don't** use pure black (#000000) for text. Always use `on-surface` (#30323b) for a softer, premium look.
- **Don't** use `rounded-none`. Even the sharpest elements need `rounded-sm` (0.25rem) to maintain the "friendly" brand promise.
- **Don't** stack more than three levels of surface nesting. If you need more depth, use a Backdrop Blur.

---

## 7. Spacing & Rhythm
Consistency is the key to clarity.
- **Container Padding:** Always `spacing-6` (2rem).
- **Task List Gap:** `spacing-1.5` (0.5rem).
- **Header-to-Content:** `spacing-8` (2.75rem).

*By following these guidelines, you ensure the design system feels less like a tool and more like a high-end personal assistant.*